# molokai_dark
molokai_dark theme for vim created by Tomas Restrepo <tomas@winterdom.com>.
I'm creating that repo cause i couldn't find the original.

# Notes from the original:

Vim color file

Author: Tomas Restrepo <tomas@winterdom.com>

Note: Based on the monokai theme for textmate by Wimer Hazenberg and its darker variant by Hamish Stuart Macpherson Eric Zhang for make it even darker and look cooler
